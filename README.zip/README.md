# multilevel

Intelligent Assistant Location:

![1](https://user-images.githubusercontent.com/10297748/209402352-b3e7061b-d7bd-45b0-9f84-44d24779cfd3.png)

Graphical representation of the problem being solved:

![2c](https://user-images.githubusercontent.com/10297748/209402362-998b597c-b5d3-4e09-b8a7-38262e158e39.png)

Smart assistant mobile app:

![3c](https://user-images.githubusercontent.com/10297748/209402371-b38d724f-8f3b-412b-8f9e-06d6410a294d.png)

Expert system for event visualization:

![4](https://user-images.githubusercontent.com/10297748/209402388-ff13f983-0de4-45b9-8f97-dc7c51da8c7f.png)

Server part:

![5](https://user-images.githubusercontent.com/10297748/209402398-2f817121-9b69-40cd-b350-2849f366c564.png)

Everything is guaranteed to work under Windows 10/11 with pre-installed libraries for Lazarus included.
